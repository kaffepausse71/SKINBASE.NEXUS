skin.HorizonzV
==============
Unterstütze Addons:
Auto Completition
Artist Slide Show
Artwork Beef
CDArt Manager
Extended Info Script
Global Search
Fritz Smart Home (by Birger Jesch)
German Telecast Offers (by Birger Jesch)
KN Switchtimer Service (by Birger Jesch)
Library Node Editor
Skinhelper Ping (by _Andy_)
TMDbHelper (rudimentär - Anzeige der verfügbaren Provider für Filme (Nextflix, Amazon und Co.))
Reincarnation of xb2iris XBMC skin for Frodo