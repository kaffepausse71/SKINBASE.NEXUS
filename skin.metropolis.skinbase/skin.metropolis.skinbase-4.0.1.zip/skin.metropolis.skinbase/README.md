# skin.metropolis

Metropolis skin for Kodi

WIP for Kodi 19
