# Aeon Nox 5: SiLVO
A modded version of [Aeon Nox 5](http://forum.kodi.tv/showthread.php?tid=183504)

**Branches guide:**
 - **nexus:** Kodi v20 Codename Nexus
 - **matrix:** Kodi v19 Codename Matrix

*Check the [Aeon Nox 5: SiLVO thread](http://forum.kodi.tv/showthread.php?tid=210069) for more information and support*
