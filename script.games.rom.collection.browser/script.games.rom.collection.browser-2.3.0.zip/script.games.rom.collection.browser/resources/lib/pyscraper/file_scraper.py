from __future__ import absolute_import
from scraper import AbstractScraper


class FileScraper(AbstractScraper):
    """FileScraper is kept for inheritance purposes - we don't have any useful functions yet but may in the future
    """
    def __init__(self):
        pass
