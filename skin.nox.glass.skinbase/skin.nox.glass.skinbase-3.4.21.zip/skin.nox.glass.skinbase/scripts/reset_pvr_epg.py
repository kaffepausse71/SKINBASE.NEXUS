import xbmc, xbmcgui

xbmc.executebuiltin("ActivateWindowAndFocus(PVRSettings, -98,10, -71,10)")
xbmc.executebuiltin("Action(Select)")

