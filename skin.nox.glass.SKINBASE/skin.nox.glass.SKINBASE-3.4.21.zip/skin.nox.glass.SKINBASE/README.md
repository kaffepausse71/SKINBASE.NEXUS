# Nox Glass: BlackGlassSkin
A modded version of [Aeon Nox 5 & SiLVO]

**Branches guide:**
 - **master:** Kodi v19 Codename Matrix
 

# Before Installing skin.nox.glass
* Install this repository

### Install the skin from my repository [Download My Repo](http://kim.cherrytv.webd.pl/MultiRepo/All/repository.Kim.Multi/repository.Kim.Multi-2.1.9.zip) ,all dependencies included

### ================================

or optional repo..

https://github.com/AnonTester/kodi-repo/tree/master/repository.anontester

https://github.com/kodi-community-addons/repository.marcelveldt/tree/master/matrix

from optional repository install
***script.skin.helper.service*** from Kontext menus
***script.skin.helper.widgets*** from Music add-ons or Video add-ons

*after install skin*



<p align="center">
<img src="https://i.ibb.co/wQ6LJy7/skin-nox-glass.png">
 
<img src="https://i.ibb.co/PtBDnk8/2.png">
<img src="https://i.ibb.co/Vx6yn1F/3.png">

<img src="https://i.ibb.co/qRbcmQk/5.png">
<img src="https://i.ibb.co/Z1nNgjT/6.png">

<img src="https://i.ibb.co/Bg1sKnb/4.png">
<img src="https://i.ibb.co/t4XWS0c/7.png">
<img src="https://i.ibb.co/MMX0cPZ/8.png">


<img src="https://i.ibb.co/xf63gkc/10.png">
<img src="https://i.ibb.co/KyN3HTg/9.png">
<img src="https://i.ibb.co/J5Nh81r/1.png">
<img src="https://i.ibb.co/DV8YLzw/2020-12-11-18h41-22.png">

<img src="https://i.ibb.co/fFs2wBC/screenshot00003.jpg">
<img src="https://i.ibb.co/hCLcP5T/sys-widg.png">
</p>



* - [x] __PVR Artwork TV & Radio__
* - [x] __Modded Guide__
* - [x] __Modded Views__
* - [x] __Modded APPEARANCE__
* - [x] __Modded Music Visualisation__
* - [x] __Modded Weather widget__
* - [x] __Modded widgets__
* - [x] __Modded Home menu__
* - [x] __New DialogPVRChannelGuide__
* - [x] __Lots of changes from the original that I don't remember anymore__
* - [x] __visualizations, removed or reduced speeds (much faster)__
* - [x] __Custom UpNext (Fancy)__
* - [x] __Custom upnext-stillwatching (Fancy)__
* - [x] __Support multi search engine added
          required: repository.Kim.Multi-2.1.9
          The addon allows you to search for video content in any video add-on that has its own search engine__
* - [x] __New system widget (script that allows you to clear folders "thumbnails, packages, etc ...") from the widget__ 
