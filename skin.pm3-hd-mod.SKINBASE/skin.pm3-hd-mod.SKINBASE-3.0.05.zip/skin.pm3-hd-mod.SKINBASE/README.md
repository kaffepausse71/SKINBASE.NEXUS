The main goal of this branch is to add Leia (Kodi 18) support to this very fine skin made by JezzX.
